I was unable to add @{{user}} as a collaborator.

{{>error}}