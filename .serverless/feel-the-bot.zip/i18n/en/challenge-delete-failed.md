I was unable to delete challenge.

{{>error}}