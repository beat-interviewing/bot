Created challenge [{{repoOwner}}/{{repo}}](/{{repoOwner}}/{{repo}}) for @{{candidate}}.

When ready, use `/join @{{candidate}}` to invite them as a collaborator.