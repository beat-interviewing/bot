/challenge @{{username}}

_[{{ firstName }} {{ lastName }}]({{{ profileUrl }}}) <[{{{ email }}}]({{{ email }}})> via [Greenhouse]({{{ url }}})_